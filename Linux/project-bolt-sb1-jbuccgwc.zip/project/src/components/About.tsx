import React from 'react';
import { GraduationCap, Target, Code, Server } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Driven by curiosity for how systems run, break, and scale
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg text-gray-700 leading-relaxed">
              My journey into DevOps is rooted in curiosity for how systems run, break, and scale. 
              I'm building my skills through disciplined learning, homelab experimentation, and 
              project-based execution.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              As a computer science master's student graduating in May 2025, I'm passionate about 
              Linux, DevOps, and cloud-native technologies. I'm currently undergoing intensive 
              self-training in areas like CI/CD, Infrastructure as Code, and Monitoring.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              My goal is to land a DevOps role with a strong foundation in system administration 
              and automation, bringing reliability and efficiency to modern infrastructure.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <GraduationCap className="h-8 w-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Education</h3>
              <p className="text-sm text-gray-600">Master's in CS<br />FAU, May 2025</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <Target className="h-8 w-8 text-green-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Focus</h3>
              <p className="text-sm text-gray-600">DevOps<br />& Cloud Infrastructure</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <Code className="h-8 w-8 text-purple-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Automation</h3>
              <p className="text-sm text-gray-600">CI/CD Pipelines<br />& IaC</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <Server className="h-8 w-8 text-orange-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Systems</h3>
              <p className="text-sm text-gray-600">Linux Admin<br />& Monitoring</p>
            </div>
          </div>
        </div>

        <div className="mt-16 bg-blue-50 rounded-lg p-8">
          <blockquote className="text-center">
            <p className="text-xl font-medium text-gray-900 mb-4">
              "Great systems are built with empathy, automation, and relentless curiosity."
            </p>
            <footer className="text-gray-600">— My approach to DevOps</footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
};

export default About;