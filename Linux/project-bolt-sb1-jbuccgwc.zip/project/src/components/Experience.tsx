import React from 'react';
import { Briefcase, Search, MapPin, Calendar } from 'lucide-react';

const Experience = () => {
  return (
    <section id="experience" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Experience</h2>
          <p className="text-xl text-gray-600">
            Ready to apply DevOps skills in real-world production environments
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 text-center">
          <div className="mb-6">
            <Search className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Seeking DevOps Opportunities</h3>
          </div>

          <div className="max-w-2xl mx-auto mb-8">
            <p className="text-lg text-gray-700 mb-6">
              Currently seeking an <span className="font-semibold text-blue-600">unpaid DevOps internship</span> to 
              support visa compliance (OPT) and apply my skills in real-world production environments.
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 text-left">
              <div className="bg-white rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3">What I Bring</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Strong Linux system administration skills</li>
                  <li>• Hands-on experience with CI/CD pipelines</li>
                  <li>• Cloud infrastructure knowledge (AWS)</li>
                  <li>• Passion for automation and reliability</li>
                  <li>• Continuous learning mindset</li>
                </ul>
              </div>
              
              <div className="bg-white rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3">What I'm Looking For</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• DevOps Engineer (Entry-level/Intern)</li>
                  <li>• Site Reliability Engineer</li>
                  <li>• Cloud Infrastructure Engineer</li>
                  <li>• Platform Engineer</li>
                  <li>• Build/Release Engineer</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8 text-gray-600">
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-2" />
              <span>Florida & Remote</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              <span>Available: January 2025</span>
            </div>
            <div className="flex items-center">
              <Briefcase className="h-4 w-4 mr-2" />
              <span>F-1 Visa (OPT Eligible)</span>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Academic Projects & Labs</h3>
          <div className="bg-gray-50 rounded-lg p-6">
            <p className="text-gray-700">
              Throughout my Master's program at Florida Atlantic University, I've worked on various 
              system administration and software development projects. These academic experiences, 
              combined with my self-directed DevOps learning, provide a solid foundation for 
              professional DevOps work.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;