import React from 'react';
import { Github, ExternalLink, Calendar, Wrench } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: "Automated CI/CD Pipeline for Flask App",
      description: "Complete DevOps pipeline with GitHub Actions, Docker containerization, and automated deployment to AWS EC2. Includes infrastructure provisioning with Terraform and monitoring setup.",
      tools: ["GitHub Actions", "Docker", "AWS EC2", "Terraform", "Flask", "Bash"],
      status: "In Progress",
      githubUrl: "#",
      liveUrl: "#",
      isComingSoon: true
    },
    {
      title: "Infrastructure as Code with Terraform",
      description: "Multi-environment AWS infrastructure setup using Terraform modules. Includes VPC configuration, security groups, load balancers, and auto-scaling groups with proper state management.",
      tools: ["Terraform", "AWS", "VPC", "EC2", "ALB", "Auto Scaling"],
      status: "Planning",
      githubUrl: "#",
      liveUrl: "#",
      isComingSoon: true
    },
    {
      title: "Kubernetes Cluster Monitoring Stack",
      description: "Complete monitoring solution for Kubernetes clusters using Prometheus, Grafana, and AlertManager. Includes custom dashboards and automated alerting for system health and performance metrics.",
      tools: ["Kubernetes", "Prometheus", "Grafana", "AlertManager", "Helm"],
      status: "Planning",
      githubUrl: "#",
      liveUrl: "#",
      isComingSoon: true
    },
    {
      title: "Ansible Configuration Management",
      description: "Automated server configuration and application deployment using Ansible playbooks. Includes role-based configurations, secret management, and multi-environment support.",
      tools: ["Ansible", "YAML", "Linux", "SSH", "Vault", "Jinja2"],
      status: "Planning",
      githubUrl: "#",
      liveUrl: "#",
      isComingSoon: true
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Progress':
        return 'bg-blue-100 text-blue-800';
      case 'Planning':
        return 'bg-yellow-100 text-yellow-800';
      case 'Completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">DevOps Projects</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Hands-on projects demonstrating end-to-end DevOps practices and automation
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-xl font-semibold text-gray-900 flex-1 pr-4">
                    {project.title}
                  </h3>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(project.status)}`}>
                    {project.status}
                  </span>
                </div>

                <p className="text-gray-600 mb-6">{project.description}</p>

                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.tools.map((tool, toolIndex) => (
                      <span
                        key={toolIndex}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4">
                  {project.isComingSoon ? (
                    <>
                      <div className="flex items-center text-gray-400 cursor-not-allowed">
                        <Github className="h-4 w-4 mr-2" />
                        <span className="text-sm">Coming Soon</span>
                      </div>
                      <div className="flex items-center text-gray-400 cursor-not-allowed">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        <span className="text-sm">Coming Soon</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-gray-700 hover:text-gray-900 transition-colors"
                      >
                        <Github className="h-4 w-4 mr-2" />
                        <span className="text-sm">Code</span>
                      </a>
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        <span className="text-sm">Live Demo</span>
                      </a>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-blue-50 rounded-lg p-8 text-center">
          <Wrench className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-4">More Projects Coming Soon</h3>
          <p className="text-gray-600 max-w-2xl mx-auto mb-6">
            I'm actively working on building a comprehensive portfolio of DevOps projects. 
            Each project focuses on real-world scenarios and best practices in automation, 
            infrastructure, and system reliability.
          </p>
          <div className="flex justify-center">
            <div className="flex items-center text-gray-600">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="text-sm">Expected completion: Q1-Q2 2025</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;