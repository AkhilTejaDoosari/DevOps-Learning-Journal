import React from 'react';
import { BookOpen, Target, TrendingUp, Award } from 'lucide-react';

const LearningPath = () => {
  const learningPrinciples = [
    {
      principle: "Pareto Principle",
      description: "Focus on the 20% of skills that deliver 80% of results",
      icon: <Target className="h-5 w-5" />
    },
    {
      principle: "Parkinson's Law",
      description: "Set tight deadlines to maximize focus and efficiency",
      icon: <TrendingUp className="h-5 w-5" />
    },
    {
      principle: "Feynman Technique",
      description: "Learn by teaching and explaining concepts simply",
      icon: <BookOpen className="h-5 w-5" />
    }
  ];

  const currentCourses = [
    {
      title: "The Ultimate Linux Bootcamp for DevOps",
      provider: "Udemy",
      progress: 75,
      status: "In Progress"
    },
    {
      title: "Docker & Kubernetes: The Practical Guide",
      provider: "Udemy",
      progress: 60,
      status: "In Progress"
    },
    {
      title: "AWS Certified Solutions Architect Associate",
      provider: "AWS",
      progress: 40,
      status: "In Progress"
    },
    {
      title: "4+ End-to-End DevOps Projects",
      provider: "Self-Directed",
      progress: 30,
      status: "In Progress"
    }
  ];

  return (
    <section id="learning" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Learning Journey</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Continuous learning through structured approach and proven methodologies
          </p>
        </div>

        <div className="bg-blue-50 rounded-lg p-8 mb-12">
          <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Learning Philosophy</h3>
          <p className="text-lg text-gray-700 text-center mb-8 italic">
            "I follow productivity principles like the Pareto Principle, Parkinson's Law, and the Feynman Technique 
            to ensure smart, efficient learning."
          </p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {learningPrinciples.map((item, index) => (
              <div key={index} className="bg-white rounded-lg p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 text-blue-600 rounded-lg mb-4">
                  {item.icon}
                </div>
                <h4 className="font-semibold text-gray-900 mb-3">{item.principle}</h4>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">Current Learning Path</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {currentCourses.map((course, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2">{course.title}</h4>
                    <p className="text-gray-600 text-sm mb-3">{course.provider}</p>
                  </div>
                  <span className="px-3 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                    {course.status}
                  </span>
                </div>
                
                <div className="mb-2">
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Progress</span>
                    <span>{course.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${course.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-lg">
            <Award className="h-5 w-5 mr-2" />
            <span className="font-medium">Target: AWS Solutions Architect Associate by Q2 2025</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LearningPath;