import React from 'react';
import { 
  Terminal, 
  Cloud, 
  GitBranch, 
  Container, 
  Monitor, 
  Settings, 
  Database,
  Shield
} from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: "Linux & System Administration",
      icon: <Terminal className="h-6 w-6" />,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      skills: ["Ubuntu", "CentOS", "Shell Scripting (Bash)", "Systemd", "Cron", "Networking"]
    },
    {
      title: "Cloud & Infrastructure",
      icon: <Cloud className="h-6 w-6" />,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      skills: ["AWS (EC2, S3, IAM, VPC)", "Infrastructure as Code", "Terraform", "Cloud Architecture"]
    },
    {
      title: "CI/CD & Version Control",
      icon: <GitBranch className="h-6 w-6" />,
      color: "text-green-600",
      bgColor: "bg-green-50",
      skills: ["Git & GitHub", "GitHub Actions", "Jenkins", "Pipeline Automation"]
    },
    {
      title: "Containerization & Orchestration",
      icon: <Container className="h-6 w-6" />,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      skills: ["Docker", "Kubernetes", "Container Registry", "Microservices"]
    },
    {
      title: "Monitoring & Observability",
      icon: <Monitor className="h-6 w-6" />,
      color: "text-red-600",
      bgColor: "bg-red-50",
      skills: ["Prometheus", "Grafana", "Log Management", "Alerting Systems"]
    },
    {
      title: "Configuration Management",
      icon: <Settings className="h-6 w-6" />,
      color: "text-indigo-600",
      bgColor: "bg-indigo-50",
      skills: ["Ansible", "YAML", "JSON", "Configuration Automation"]
    },
    {
      title: "Programming & Scripting",
      icon: <Database className="h-6 w-6" />,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      skills: ["Python (Scripting)", "Bash Scripting", "YAML/JSON", "API Integration"]
    },
    {
      title: "Methodology & Practices",
      icon: <Shield className="h-6 w-6" />,
      color: "text-gray-600",
      bgColor: "bg-gray-50",
      skills: ["Agile/Scrum", "DevSecOps", "Security Best Practices", "Documentation"]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Skills & Technologies</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Building expertise across the DevOps toolchain with hands-on practice and continuous learning
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow duration-200"
            >
              <div className="flex items-center mb-4">
                <div className={`p-3 rounded-lg ${category.bgColor} ${category.color} mr-4`}>
                  {category.icon}
                </div>
                <h3 className="text-lg font-semibold text-gray-900">{category.title}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, skillIndex) => (
                  <span
                    key={skillIndex}
                    className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full hover:bg-gray-200 transition-colors duration-200"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-lg p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Currently Pursuing</h3>
            <div className="flex flex-wrap justify-center gap-3">
              <span className="px-4 py-2 bg-blue-100 text-blue-800 font-medium rounded-lg">
                AWS Solutions Architect Associate
              </span>
              <span className="px-4 py-2 bg-green-100 text-green-800 font-medium rounded-lg">
                Kubernetes Certification (CKA)
              </span>
              <span className="px-4 py-2 bg-purple-100 text-purple-800 font-medium rounded-lg">
                Advanced Docker & Kubernetes
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;