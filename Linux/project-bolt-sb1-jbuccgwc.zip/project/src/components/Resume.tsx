import React from 'react';
import { Download, Eye, FileText } from 'lucide-react';

const Resume = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Resume</h2>
          <p className="text-xl text-gray-600">
            Download my complete resume for detailed information
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="bg-blue-100 p-4 rounded-lg mr-6">
                <FileText className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Akhil Teja Doosari - Resume</h3>
                <p className="text-gray-600">DevOps Engineer | Computer Science Graduate</p>
                <p className="text-sm text-gray-500">Last updated: December 2024</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <button className="inline-flex items-center px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors duration-200">
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </button>
              <a
                href="/resume.pdf"
                download
                className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </a>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-4">Resume Highlights</h4>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h5 className="font-medium text-gray-900 mb-2">Education</h5>
                <ul className="text-gray-600 space-y-1">
                  <li>• Master's in Computer Science - FAU (May 2025)</li>
                  <li>• Strong academic foundation in systems</li>
                  <li>• Relevant coursework in networking and databases</li>
                </ul>
              </div>
              <div>
                <h5 className="font-medium text-gray-900 mb-2">Key Skills</h5>
                <ul className="text-gray-600 space-y-1">
                  <li>• Linux System Administration</li>
                  <li>• AWS Cloud Services</li>
                  <li>• Docker & Kubernetes</li>
                  <li>• CI/CD Pipeline Development</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-blue-800 text-sm">
              <strong>Note:</strong> This resume is specifically tailored for DevOps and Site Reliability Engineer positions, 
              highlighting relevant technical skills, projects, and learning journey.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;